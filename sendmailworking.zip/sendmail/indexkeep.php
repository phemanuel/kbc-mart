<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
  
require 'vendor/autoload.php';

$fullname = "Akinyooye Akinfemi";
$verifycode = "etr47586";
//======prepare message=====
$message1= "Welcome To Oyo State College of Health Science and Technology." ;
$message2 = "Hi ". $fullname . ",";
$message3 = "Thank you for choosing our college. We are close to finalizing your sign up and you  are left with just a click. We may need to send you critical information about our service and it is important that we have an accurate email address. ";
$message4 = "Copy the url into your browser to confirm your email address by entering your verification code. ";
$message5 = "Verification Code - " . $verifycode ;
$message6 = "https://www.oyschst.edu.ng/testmail/verify.php";
$message7 = "Copyright © Oyo State College of Health Science and Technology, Eleyele, Ibadan. All rights reserved";
$message8 = "Our mailing address is: 6, Paul Okonye Street, Federal Housing Authority, Kubwa, Abuja 900101, Nigeria";
$message9 = "You are receiving this email from Oyo State College of Health Science and Technology as a user who made a payment transaction. ";
//--------build message-------------------------
	$message = '<html><body>';
			$message .= '<img src="http://oyschst.edu.ng/testmail/images/oyschstlogo.png" alt="OYSCHST" />';
			$message .= '<table rules="all" style="border-color: #fff;" cellpadding="10">';
		
			$message .= "<tr><td>". strip_tags($message1) ."<br><br>". strip_tags($message2) ."<br><br>". strip_tags($message3) ."<br><br>". strip_tags($message4) ."<br><br>". strip_tags($message5) ."<br><br>". strip_tags($message6) ."<br><br>". strip_tags($message7) ."<br><br>". strip_tags($message8) ."<br><br>" . strip_tags($message9) ." </td></tr>";
				$message .= "</table>";
			$message .= "</body></html>";

//=======
  
$mail = new PHPMailer(true);
  
//try {

$mail->SMTPDebug = 2;                   // Enable verbose debug output
$mail->isSMTP();                        // Set mailer to use SMTP
$mail->Host       = 'mail.oyschst.edu.ng';    // Specify main SMTP server
$mail->SMTPAuth   = true;               // Enable SMTP authentication
$mail->SMTPSecure = 'ssl';  
$mail->Port       = 465; 
$mail->Username   = 'no-reply@oyschst.edu.ng';     // SMTP username
$mail->Password   = 'noreply@2022';         // SMTP password
            // Enable TLS encryption, 'ssl' also accepted
               // TCP port to connect to
//=====

  
    $mail->setFrom('no-reply@oyschst.edu.ng', 'OYSCHST');           
    $mail->addAddress('emmakinyooye@gmail.com');
    $mail->addAddress('phemanuel@yahoo.com');
       
    $mail->isHTML(true);                                  
    $mail->Subject = 'E-payment Notification';
    $mail->Body    = $message;
    $mail->AltBody = 'Body in plain text for non-HTML mail clients';
    $mail->send();
    echo "<script>
alert('Mail has been sent successfully.');
window.location.href='https://oyschst.edu.ng';
</script>";
// } catch (Exception $e) {
//     echo "<script>
// alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}');
// window.location.href='https://oyschst.edu.ng';
// </script>";
    
// }
?>

